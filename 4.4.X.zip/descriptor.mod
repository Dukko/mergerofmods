name="IronyModManager_4.4.X"
tags={
	"Fixes"
}
supported_version="v4.4.*"
